==========================
django CMS Code of Conduct
==========================

django CMS is governed by a `Code of Conduct
<http://docs.django-cms.org/en/latest/contributing/code_of_conduct.html>`_.
All participants in our community and its various forums are expected to abide by it.
