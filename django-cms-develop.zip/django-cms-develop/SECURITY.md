# Security Policy

## Reporting a Vulnerability

As ever, we remind our users and contributors that all security reports, patches and concerns be addressed only to our security team by email, at security@django-cms.org.
