from .cms_sitemap import CMSSitemap  # nopyflakes
